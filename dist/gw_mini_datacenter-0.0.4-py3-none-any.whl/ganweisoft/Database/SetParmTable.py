class SetParmTableRow:
    def __init__(self):
        self.sta_n = None
        self.equip_no = None
        self.set_no = None
        self.set_nm = None
        self.set_type = None
        self.main_instruction = None
        self.minor_instruction = None
        self.record = None
        self.action = None
        self.value = None
        self.canexecution = None
        self.VoiceKeys = None
        self.EnableVoice = None
        self.qr_equip_no = 0
        self.Reserve1 = None
        self.Reserve2 = None
        self.Reserve3 = None
        self.set_code = None