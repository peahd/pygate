class GWExProcCmdTableRow:
    def __init__(self):
        self.proc_code = None
        self.cmd_nm = None
        self.main_instruction = None
        self.minor_instruction = None
        self.value = None
        self.record = None