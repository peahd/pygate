class GWExProcTableRow:
    def __init__(self):
        self.Proc_Code = None
        self.Proc_Module = None
        self.Proc_name = None
        self.Proc_parm = None
        self.Reserve1 = None
        self.Reserve2 = None
        self.Reserve3 = None